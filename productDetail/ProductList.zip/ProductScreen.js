import React,{useState} from 'react';
import { View, Text,StyleSheet ,ScrollView,TextInput  } from 'react-native';
import ProductList from './ProductList.js'
import Headercomponent2 from '../productDetail/header2component.js';


const Productname = ( props ) => {
    const [text, setText] = useState('');
    const myProductArray = [
        { id: 'prod1', indate: '2025-01-11', expiredate: '2025-06-11', count: 3 },
        { id: 'prod2', indate: '2025-02-20', expiredate: '2025-07-20', count: 5 },
        { id: 'prod3', indate: '2025-03-15', expiredate: '2025-08-15', count: 10 },
        { id: 'prod4', indate: '2025-04-01', expiredate: '2025-09-01', count: 7 },
      ];

  return (
    <View>
        <Headercomponent2 headertext="헤더 예시" />
        <Text style={stylesname.product}>{props.producttext}</Text>
        <Text style={stylesname.totalquantity}>총 수량: {props.count}</Text>
        //<Text style= {stylesname.batches}>{}</Text>
        <TextInput
            style={stylesname.input}
            placeholder="여기에 입력..."
            value={text}
            onChangeText={(newText) => setText(newText)}
        />
        //<ProductList indate="2025-01-11" expiredate="2025-06-11" count="3" />
        <ScrollView>
        {myProductArray.map((product)=> (
                <ProductList
                            key={product.id}
                            indate={product.expiredate}
                            expiredate={product.expiredate}
                            count={product.count}
                            />

        ))}
        </ScrollView>
    </View>
  );
};
const stylesname = StyleSheet.create({
    product : {
        fontSize: 20,

        fontWeight: 'bold',
        padding: 10, paddingLeft: 15,
        width: '100%',
    },
    totalquantity: {
        fontSize: 15,
        paddingHorizontal: 15,
        width: '100%',


    },
    batches: {
        fontSize : 20,
        fontWeight: 'bold',
        padding : 15,

    },
    input: {

        borderColor: 'gray',
        borderWidth: 1,
        borderRadius: 5,
        marginBottom: 20,
        margin: 10,
        paddingHorizontal: 10,

    }
  });

export default Productname;
